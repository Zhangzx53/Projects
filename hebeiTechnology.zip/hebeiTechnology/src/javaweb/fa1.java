package javaweb;

public class fa1 {
	String no;
	String riqi;
	String wenhao;
	String lingyu;
	String jibei;
	String suozaidi;
	String faren;
	String jianshe;
	String gongjian;
	String hangyeo;
	String hangyet;
	String hangyes;
	String xuekeo;
	String xueket;
	String xuekes;
	String dname;
	String daima;
	String danleixing;
	String gongdanwei;
	String zanname;
	String wangzi;
	String tongdizhi;
	String youbian;
	String yuanname;
	String sex;
	String niamyue;
	String zhicheng;
	String zhuanye;
	String xueli;
	String xuewei;
	String dianhua;
	String shuoji;
	String youxiang;
	
	public fa1(String a,String b,String c,String d,String e,String f,String g,String h,String i,String j,String k,String l,String m,String n,String o,String p,String q,String r,String s,String t,String u,String v,String w,String xx,String y,String z,String aa,String bb,String cc,String dd,String ee,String ff,String gg) {
		this.no= a;
		this.riqi= b;
		this.wenhao= c;
		this.lingyu= d;
		this.jibei= e;
		this.suozaidi= f;
		this.faren= g;
		this.jianshe= h;
		this.gongjian= i;
		this.hangyeo= g;
		this.hangyet= k;
		this.hangyes= l;
		this.xuekeo= m;
		this.xueket= n;
		this.xuekes= o;
		this.dname= p;
		this.daima= q;
		this.danleixing= r;
		this.gongdanwei= s;
		this.zanname= t;
		this.wangzi= u;
		this.tongdizhi= v;
		this.youbian= w;
		this.yuanname= xx;
		this.sex= y;
		this.niamyue= z;
		this.zhicheng= aa;
		this.zhuanye= bb;
		this.xueli= cc;
		this.xuewei= dd;
		this.dianhua= ee;
		this.shuoji= ff;
		this.youxiang= gg;
		
	}

	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getRiqi() {
		return riqi;
	}
	public void setRiqi(String riqi) {
		this.riqi = riqi;
	}
	public String getWenhao() {
		return wenhao;
	}
	public void setWenhao(String wenhao) {
		this.wenhao = wenhao;
	}
	public String getLingyu() {
		return lingyu;
	}
	public void setLingyu(String lingyu) {
		this.lingyu = lingyu;
	}
	public String getJibei() {
		return jibei;
	}
	public void setJibei(String jibei) {
		this.jibei = jibei;
	}
	public String getSuozaidi() {
		return suozaidi;
	}
	public void setSuozaidi(String suozaidi) {
		this.suozaidi = suozaidi;
	}
	public String getFaren() {
		return faren;
	}
	public void setFaren(String faren) {
		this.faren = faren;
	}
	public String getJianshe() {
		return jianshe;
	}
	public void setJianshe(String jianshe) {
		this.jianshe = jianshe;
	}
	public String getGongjian() {
		return gongjian;
	}
	public void setGongjian(String gongjian) {
		this.gongjian = gongjian;
	}
	public String getHangyeo() {
		return hangyeo;
	}
	public void setHangyeo(String hangyeo) {
		this.hangyeo = hangyeo;
	}
	public String getHangyet() {
		return hangyet;
	}
	public void setHangyet(String hangyet) {
		this.hangyet = hangyet;
	}
	public String getHangyes() {
		return hangyes;
	}
	public void setHangyes(String hangyes) {
		this.hangyes = hangyes;
	}
	public String getXuekeo() {
		return xuekeo;
	}
	public void setXuekeo(String xuekeo) {
		this.xuekeo = xuekeo;
	}
	public String getXueket() {
		return xueket;
	}
	public void setXueket(String xueket) {
		this.xueket = xueket;
	}
	public String getXuekes() {
		return xuekes;
	}
	public void setXuekes(String xuekes) {
		this.xuekes = xuekes;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDaima() {
		return daima;
	}
	public void setDaima(String daima) {
		this.daima = daima;
	}
	public String getDanleixing() {
		return danleixing;
	}
	public void setDanleixing(String danleixing) {
		this.danleixing = danleixing;
	}
	public String getGongdanwei() {
		return gongdanwei;
	}
	public void setGongdanwei(String gongdanwei) {
		this.gongdanwei = gongdanwei;
	}
	public String getZanname() {
		return zanname;
	}
	public void setZanname(String zanname) {
		this.zanname = zanname;
	}
	public String getWangzi() {
		return wangzi;
	}
	public void setWangzi(String wangzi) {
		this.wangzi = wangzi;
	}
	public String getTongdizhi() {
		return tongdizhi;
	}
	public void setTongdizhi(String tongdizhi) {
		this.tongdizhi = tongdizhi;
	}
	public String getYoubian() {
		return youbian;
	}
	public void setYoubian(String youbian) {
		this.youbian = youbian;
	}
	public String getYuanname() {
		return yuanname;
	}
	public void setYuanname(String yuanname) {
		this.yuanname = yuanname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getNiamyue() {
		return niamyue;
	}
	public void setNiamyue(String niamyue) {
		this.niamyue = niamyue;
	}
	public String getZhicheng() {
		return zhicheng;
	}
	public void setZhicheng(String zhicheng) {
		this.zhicheng = zhicheng;
	}
	public String getZhuanye() {
		return zhuanye;
	}
	public void setZhuanye(String zhuanye) {
		this.zhuanye = zhuanye;
	}
	public String getXueli() {
		return xueli;
	}
	public void setXueli(String xueli) {
		this.xueli = xueli;
	}
	public String getXuewei() {
		return xuewei;
	}
	public void setXuewei(String xuewei) {
		this.xuewei = xuewei;
	}
	public String getDianhua() {
		return dianhua;
	}
	public void setDianhua(String dianhua) {
		this.dianhua = dianhua;
	}
	public String getShuoji() {
		return shuoji;
	}
	public void setShuoji(String shuoji) {
		this.shuoji = shuoji;
	}
	public String getYouxiang() {
		return youxiang;
	}
	public void setYouxiang(String youxiang) {
		this.youxiang = youxiang;
	}



	
	
	
}
