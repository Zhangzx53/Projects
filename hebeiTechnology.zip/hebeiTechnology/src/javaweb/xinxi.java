package javaweb;

public class xinxi {
	private int id;
	private String username;
	private String pingtainame;
	private String yituodanwei;
	private String pingtaijibie;
	private String pingtaileixing;
	private String pizhunwenhao;
	private String pizhunriqi;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPingtainame() {
		return pingtainame;
	}
	public void setPingtainame(String pingtainame) {
		this.pingtainame = pingtainame;
	}
	public String getYituodanwei() {
		return yituodanwei;
	}
	public void setYituodanwei(String yituodanwei) {
		this.yituodanwei = yituodanwei;
	}
	public String getPingtaijibie() {
		return pingtaijibie;
	}
	public void setPingtaijibie(String pingtaijibie) {
		this.pingtaijibie = pingtaijibie;
	}
	public String getPingtaileixing() {
		return pingtaileixing;
	}
	public void setPingtaileixing(String pingtaileixing) {
		this.pingtaileixing = pingtaileixing;
	}
	public String getPizhunwenhao() {
		return pizhunwenhao;
	}
	public void setPizhunwenhao(String pizhunwenhao) {
		this.pizhunwenhao = pizhunwenhao;
	}public String getPizhunriqi() {
		return pizhunriqi;
	}
	public void setPizhunriqi(String pizhunriqi) {
		this.pizhunriqi = pizhunriqi;
	}
	public xinxi(int id,String pingtainame,String yituodanwei,String pingtaijibie,String pingtaileixing,String pizhunwenhao,String pizhunriqi,String username){
    	this.id=id;
    	this.pingtainame=pingtainame;
    	this.yituodanwei=yituodanwei;
    	this.pingtaijibie=pingtaijibie;
    	this.pingtaileixing=pingtaileixing;
    	this.pizhunwenhao=pizhunwenhao;
    	this.pizhunriqi=pizhunriqi;
    	this.username=username;
    }
	public xinxi(String pingtainame,String yituodanwei,String pingtaijibie,String pingtaileixing,String pizhunwenhao,String pizhunriqi,String username){
		this.pingtainame=pingtainame;
    	this.yituodanwei=yituodanwei;
    	this.pingtaijibie=pingtaijibie;
    	this.pingtaileixing=pingtaileixing;
    	this.pizhunwenhao=pizhunwenhao;
    	this.pizhunriqi=pizhunriqi;
    	this.username=username;
    }
}
