package javaweb;

public class plat {

	public  String no;
	public String getNo() {
		return no;
	}


	public void setNo(String no) {
		this.no = no;
	}


	public String getRiqi() {
		return riqi;
	}


	public void setRiqi(String riqi) {
		this.riqi = riqi;
	}


	public  String riqi;

	
	public plat(String Plat_name,String Plat_id){
		this.no =Plat_name ;
		this.riqi = Plat_id;
	}




	
}
