package javaweb;

public class Showlist {
	private String pingtainame;
	private String ren_name;
	private String pizhunriqi;
	private String tianbiaoriqi;
	public String getPingtainame() {
		return pingtainame;
	}
	public void setPingtainame(String pingtainame) {
		this.pingtainame = pingtainame;
	}
	public String getRen_name() {
		return ren_name;
	}
	public void setRen_name(String ren_name) {
		this.ren_name = ren_name;
	}
	
	public String getPizhunriqi() {
		return pizhunriqi;
	}
	public void setPizhunriqi(String pizhunriqi) {
		this.pizhunriqi = pizhunriqi;
	}
	public String getTianbiaoriqi() {
		return tianbiaoriqi;
	}
	public void setTianbiaoriqi(String tianbiaoriqi) {
		this.tianbiaoriqi = tianbiaoriqi;
	}

	public Showlist(String pingtainame,String pizhunriqi,String ren_name,String tianbiaoriqi){
    	this.pingtainame=pingtainame;
    	this.pizhunriqi=pizhunriqi;
    	this.ren_name=ren_name;
    	this.tianbiaoriqi=tianbiaoriqi;
    }
}