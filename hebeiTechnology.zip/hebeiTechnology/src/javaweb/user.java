package javaweb;

public class user {
	private int id;
	private String username;
	private String password;
	private int number;
	
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	
	
	public user() {}
	
	public user(int id, String username, String password,int number) {
		this.id= id;
		this.username = username;
		this.password = password;
		this.number=number;
	}
	
	public user(String username, String password) {
		this.username = username;
		this.password = password;
}
}