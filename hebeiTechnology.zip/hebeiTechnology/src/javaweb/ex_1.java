package javaweb;

public class ex_1 {

	public String PlatId;
	public String Platname;
	public String Approvaldate;
	public String ApprovalId;
	public String Field;
	public String Level;
	public String Place;
	public String Organ_form;
	public String Major_industries1;
	public String Major_industries2;
	public String Major_industries3;
	public String Main_disciplines1;
	public String Main_disciplines2;
	public String Main_disciplines3;
	public String Unit_name;
	public String Unit_id;
	public String Unit_user;
	public String Unit_number;
	public String Unit_class;
	public String if_jjj;
	public String Construction_unit;
	public String Plat_name;
	public String Website;
	public String Mail_address;
	public String Postal_code;
	public String Plat_user_name;
	public String Plat_user_sex;
	public String Plat_user_birth;
	public String Plat_user_title;
	public String Plat_user_major;
	public String Plat_user_education;
	public String Plat_user_academic;
	public String Plat_user_phone;
	public String Plat_user_telephone;
	public String Plat_user_mail;
	public String getPlatId() {
		return PlatId;
	}
	public void setPlatId(String platId) {
		PlatId = platId;
	}
	public String getPlatname() {
		return Platname;
	}
	public void setPlatname(String platname) {
		Platname = platname;
	}
	public String getApprovaldate() {
		return Approvaldate;
	}
	public void setApprovaldate(String approvaldate) {
		Approvaldate = approvaldate;
	}
	public String getApprovalId() {
		return ApprovalId;
	}
	public void setApprovalId(String approvalId) {
		ApprovalId = approvalId;
	}
	public String getField() {
		return Field;
	}
	public void setField(String field) {
		Field = field;
	}
	public String getLevel() {
		return Level;
	}
	public void setLevel(String level) {
		Level = level;
	}
	public String getPlace() {
		return Place;
	}
	public void setPlace(String place) {
		Place = place;
	}
	public String getOrgan_form() {
		return Organ_form;
	}
	public void setOrgan_form(String organ_form) {
		Organ_form = organ_form;
	}
	public String getMajor_industries1() {
		return Major_industries1;
	}
	public void setMajor_industries1(String major_industries1) {
		Major_industries1 = major_industries1;
	}
	public String getMajor_industries2() {
		return Major_industries2;
	}
	public void setMajor_industries2(String major_industries2) {
		Major_industries2 = major_industries2;
	}
	public String getMajor_industries3() {
		return Major_industries3;
	}
	public void setMajor_industries3(String major_industries3) {
		Major_industries3 = major_industries3;
	}
	public String getMain_disciplines1() {
		return Main_disciplines1;
	}
	public void setMain_disciplines1(String main_disciplines1) {
		Main_disciplines1 = main_disciplines1;
	}
	public String getMain_disciplines2() {
		return Main_disciplines2;
	}
	public void setMain_disciplines2(String main_disciplines2) {
		Main_disciplines2 = main_disciplines2;
	}
	public String getMain_disciplines3() {
		return Main_disciplines3;
	}
	public void setMain_disciplines3(String main_disciplines3) {
		Main_disciplines3 = main_disciplines3;
	}
	public String getUnit_name() {
		return Unit_name;
	}
	public void setUnit_name(String unit_name) {
		Unit_name = unit_name;
	}
	public String getUnit_id() {
		return Unit_id;
	}
	public void setUnit_id(String unit_id) {
		Unit_id = unit_id;
	}
	public String getUnit_user() {
		return Unit_user;
	}
	public void setUnit_user(String unit_user) {
		Unit_user = unit_user;
	}
	public String getUnit_number() {
		return Unit_number;
	}
	public void setUnit_number(String unit_number) {
		Unit_number = unit_number;
	}
	public String getUnit_class() {
		return Unit_class;
	}
	public void setUnit_class(String unit_class) {
		Unit_class = unit_class;
	}
	public String getIf_jjj() {
		return if_jjj;
	}
	public void setIf_jjj(String if_jjj) {
		this.if_jjj = if_jjj;
	}
	public String getConstruction_unit() {
		return Construction_unit;
	}
	public void setConstruction_unit(String construction_unit) {
		Construction_unit = construction_unit;
	}
	public String getPlat_name() {
		return Plat_name;
	}
	public void setPlat_name(String plat_name) {
		Plat_name = plat_name;
	}
	public String getWebsite() {
		return Website;
	}
	public void setWebsite(String website) {
		Website = website;
	}
	public String getMail_address() {
		return Mail_address;
	}
	public void setMail_address(String mail_address) {
		Mail_address = mail_address;
	}
	public String getPostal_code() {
		return Postal_code;
	}
	public void setPostal_code(String postal_code) {
		Postal_code = postal_code;
	}
	public String getPlat_user_name() {
		return Plat_user_name;
	}
	public void setPlat_user_name(String plat_user_name) {
		Plat_user_name = plat_user_name;
	}
	public String getPlat_user_sex() {
		return Plat_user_sex;
	}
	public void setPlat_user_sex(String plat_user_sex) {
		Plat_user_sex = plat_user_sex;
	}
	public String getPlat_user_birth() {
		return Plat_user_birth;
	}
	public void setPlat_user_birth(String plat_user_birth) {
		Plat_user_birth = plat_user_birth;
	}
	public String getPlat_user_title() {
		return Plat_user_title;
	}
	public void setPlat_user_title(String plat_user_title) {
		Plat_user_title = plat_user_title;
	}
	public String getPlat_user_major() {
		return Plat_user_major;
	}
	public void setPlat_user_major(String plat_user_major) {
		Plat_user_major = plat_user_major;
	}
	public String getPlat_user_education() {
		return Plat_user_education;
	}
	public void setPlat_user_education(String plat_user_education) {
		Plat_user_education = plat_user_education;
	}
	public String getPlat_user_academic() {
		return Plat_user_academic;
	}
	public void setPlat_user_academic(String plat_user_academic) {
		Plat_user_academic = plat_user_academic;
	}
	public String getPlat_user_phone() {
		return Plat_user_phone;
	}
	public void setPlat_user_phone(String plat_user_phone) {
		Plat_user_phone = plat_user_phone;
	}
	public String getPlat_user_telephone() {
		return Plat_user_telephone;
	}
	public void setPlat_user_telephone(String plat_user_telephone) {
		Plat_user_telephone = plat_user_telephone;
	}
	public String getPlat_user_mail() {
		return Plat_user_mail;
	}
	public void setPlat_user_mail(String plat_user_mail) {
		Plat_user_mail = plat_user_mail;
	}
	public ex_1(String PlatId,String Platname,String Approvaldate,String ApprovalId,String Field,
			String Level,String Place,String Organ_form,String Major_industries1,String Major_industries2,
			String Major_industries3,String Main_disciplines1,String Main_disciplines2,String Main_disciplines3,String Unit_name,
			String Unit_id,String Unit_user,String Unit_number,String Unit_class,String if_jjj,
			String Construction_unit,String Plat_name,String Website,String Mail_address,String Postal_code,
			String Plat_user_name,String Plat_user_sex,String Plat_user_birth,String Plat_user_title,String Plat_user_major,
			String Plat_user_education,String Plat_user_academic,String Plat_user_phone,String Plat_user_telephone,String Plat_user_mail){
		this.PlatId = PlatId;;
		this.Platname = Platname;
		this.Approvaldate = Approvaldate;
		this.ApprovalId = ApprovalId;
		this.Field = Field;
		this.Level = Level;
		this.Place = Place;
		this.Organ_form = Organ_form;
		this.Major_industries1 = Major_industries1;
		this.Major_industries2 = Major_industries2;
		this.Major_industries3 = Major_industries3;
		this.Main_disciplines1 = Main_disciplines1;
		this.Main_disciplines2 = Main_disciplines2;
		this.Main_disciplines3 = Main_disciplines3;
		this.Unit_name = Unit_name;
		this.Unit_id = Unit_id;
		this.Unit_user = Unit_user;
		this.Unit_number = Unit_number;
		this.Unit_class = Unit_class;
		this.if_jjj = if_jjj;
		this.Construction_unit = Construction_unit;
		this.Plat_name = Plat_name;
		this.Website = Website;
		this.Mail_address = Mail_address;
		this.Postal_code = Postal_code;
		this.Plat_user_name = Plat_user_name;
		this.Plat_user_sex = Plat_user_sex;
		this.Plat_user_birth = Plat_user_birth;
		this.Plat_user_title = Plat_user_title;
		this.Plat_user_major = Plat_user_major;
		this.Plat_user_education = Plat_user_education;
		this.Plat_user_academic = Plat_user_academic;
		this.Plat_user_phone = Plat_user_phone;
		this.Plat_user_telephone = Plat_user_telephone;
		this.Plat_user_mail = Plat_user_mail;
		
	}
}
