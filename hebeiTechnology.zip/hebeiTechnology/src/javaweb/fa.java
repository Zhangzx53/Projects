package javaweb;

public class fa {
String no;
String name;
String fangxiang;
String neirong;

public fa(String sname, String sage, String saddress, String bumen) {

	this.no = sname;
	this.name = sage;
	this.neirong = saddress;
	this.fangxiang = bumen;
}
public fa(String sname, String sage, String saddress) {

	this.no = sname;
	this.fangxiang = sage;
	this.neirong = saddress;
}
public fa(String sname, String sage) {

	this.no = sname;
	this.name = sage;

}
public String getNo() {
	return no;
}

public void setNo(String no) {
	this.no = no;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getFangxiang() {
	return fangxiang;
}

public void setFangxiang(String fangxiang) {
	this.fangxiang = fangxiang;
}

public String getNeirong() {
	return neirong;
}

public void setNeirong(String neirong) {
	this.neirong = neirong;
}





}
