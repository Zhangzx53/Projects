package javaweb;

public class plat_1 {

	public String Platname;
	public String Field;
	public String Level;
	public String Unit_class;
	public String if_jjj;
	public String Organ_form;
	public String getPlatname() {
		return Platname;
	}
	public void setPlatname(String platname) {
		Platname = platname;
	}
	public String getField() {
		return Field;
	}
	public void setField(String field) {
		Field = field;
	}
	public String getLevel() {
		return Level;
	}
	public void setLevel(String level) {
		Level = level;
	}
	public String getUnit_class() {
		return Unit_class;
	}
	public void setUnit_class(String unit_class) {
		Unit_class = unit_class;
	}
	public String getIf_jjj() {
		return if_jjj;
	}
	public void setIf_jjj(String if_jjj) {
		this.if_jjj = if_jjj;
	}
	public String getOrgan_form() {
		return Organ_form;
	}
	public void setOrgan_form(String organ_form) {
		Organ_form = organ_form;
	}

	public plat_1(String Platname,
	String Field,
	String Level,
	String Unit_class,
	String if_jjj,
	String Organ_form){
		this.Platname = Platname;
		this.Field = Field;
		this.Level = Level;
		this.Unit_class = Unit_class;
		this.if_jjj = if_jjj;
		this.Organ_form = Organ_form;
		
	}
	
	
}
