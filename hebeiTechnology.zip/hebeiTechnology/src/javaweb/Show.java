package javaweb;

public class Show {
	private String pingtainame;
	private String ren_name;
	private String pingtaijibie;
	private String pingtaileixing;
	private String pizhunriqi;
	private String tianbiaoriqi;
	public String getPingtainame() {
		return pingtainame;
	}

	public void setPingtainame(String pingtainame) {
		this.pingtainame = pingtainame;
	}

	public String getRen_name() {
		return ren_name;
	}

	public void setRen_name(String ren_name) {
		this.ren_name = ren_name;
	}

	public String getPingtaijibie() {
		return pingtaijibie;
	}

	public void setPingtaijibie(String pingtaijibie) {
		this.pingtaijibie = pingtaijibie;
	}

	public String getPingtaileixing() {
		return pingtaileixing;
	}

	public void setPingtaileixing(String pingtaileixing) {
		this.pingtaileixing = pingtaileixing;
	}

	public String getPizhunriqi() {
		return pizhunriqi;
	}

	public void setPizhunriqi(String pizhunriqi) {
		this.pizhunriqi = pizhunriqi;
	}

	public String getTianbiaoriqi() {
		return tianbiaoriqi;
	}

	public void setTianbiaoriqi(String tianbiaoriqi) {
		this.tianbiaoriqi = tianbiaoriqi;
	}

	public Show(String pingtainame,String ren_name,String pingtaijibie,String pingtaileixing,String pizhunriqi,String tianbiaoriqi){
    	this.pingtainame=pingtainame;
    	this.ren_name=ren_name;
    	this.pingtaijibie=pingtaijibie;
    	this.pingtaileixing=pingtaileixing;
    	this.pizhunriqi=pizhunriqi;
    	this.tianbiaoriqi=tianbiaoriqi;
    }
}