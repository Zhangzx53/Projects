package javaweb;

public class faa {
	String name;
	public faa(String sname, String sage) {

		this.name = sname;
		this.wangye = sage;

	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWangye() {
		return wangye;
	}
	public void setWangye(String wangye) {
		this.wangye = wangye;
	}
	String wangye;
}
