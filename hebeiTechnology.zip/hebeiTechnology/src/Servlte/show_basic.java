package Servlte;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.dao1;
import javaweb.fa1;


@WebServlet("/show_basic")
public class show_basic extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String name=new String (req.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		
		System.out.println(name);
		fa1 basic = dao1.getex_1(name);
		
		req.setAttribute("basic_mess", basic);
		System.out.println(basic.getNo());
		
		
		req.getRequestDispatcher("show1.jsp").forward(req,resp);
	}

}