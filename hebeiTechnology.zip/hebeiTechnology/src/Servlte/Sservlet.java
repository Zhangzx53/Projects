package Servlte;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.*;
import javaweb.*;


@WebServlet("/Sservlet")
public class Sservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if ("niandu".equals(method)) 
	{
		niandu(request, response);
	}
	}

	public void niandu(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("utf-8");
		String data=new String (req.getParameter("data").getBytes("iso-8859-1"),"utf-8");	
		String pizhunriqi=new String (req.getParameter("riqi").getBytes("iso-8859-1"),"utf-8");
		if (data.equals("1")){
			data="���Ҽ�";
		}
		
		else if (data.equals("2"))
		{
			data="ʡ��";
		}else if (data.equals("3"))
		{
			data="�м�";
		}else if (data.equals("4"))
		{
			data="�ؼ�";
		}else if (data.equals("5"))
		{
			data="��ѡ��Ŀ";
		}else if (data.equals("6"))
		{
			data="������Ŀ";
		}else if (data.equals("11"))
		{
			data="��ҵ�����о�Ժ";
		}else if (data.equals("22"))
		{
			data="���̼����о�����";
		}else if (data.equals("33"))
		{
			data="�ص�ʵ����";
		}
		
			
		System.out.println(data);
		System.out.println(pizhunriqi);
		List<Show> result = null;
		result=daoxinxi.niandu(data, pizhunriqi);
		
		
		
		
		if(!result.isEmpty()){
			req.setAttribute("result", result);
			req.getRequestDispatcher("showtree.jsp").forward(req,resp);
		} else{
			req.getRequestDispatcher("showtree.jsp").forward(req,resp);
		}
	
		
	}
	
	
}
