package Servlte;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.*;
import javaweb.*;
@WebServlet("/Pservlet")
public class Pservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if ("showlist".equals(method)) 
	{
		showlist(request, response);
	}
	}
	private void showlist(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		req.setCharacterEncoding("utf-8");
		String tiaojian1 = req.getParameter("tiaojian1");
		System.out.println(tiaojian1);
		String tiaojian2=new String (req.getParameter("tiaojian2").getBytes("iso-8859-1"),"utf-8");
		
		List<Showlist> result = daocha.showlist(tiaojian1, tiaojian2);
		System.out.println(result.size());
		req.setAttribute("result", result);
		req.getRequestDispatcher("show.jsp").forward(req,resp);
	}

}

