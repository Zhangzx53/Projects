package Servlte;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.daop_cover_0;



@WebServlet("/ser_cover_0")
public class ser_cover_0 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String Platname = req.getParameter("Platname");
		String type = req.getParameter("type");
		String Unit_name = req.getParameter("Unit_name");
		String Administer = req.getParameter("Administer");
		String Preparer = req.getParameter("Preparer");
		String Department = req.getParameter("Department");
		String Phone = req.getParameter("Phone");
		String Telephone = req.getParameter("Telephone");
		String Mail = req.getParameter("Mail");
		String date = req.getParameter("date");
		
		
       
		if(daop_cover_0.insert_cover_0(Platname,type,Unit_name,Administer,Preparer,Department,Phone,Telephone,Mail,date)){
        	req.setAttribute("message", "����ɹ�");
        	req.getRequestDispatcher("cover_from.jsp").forward(req,resp);	
        }else{
        	req.setAttribute("message", "����ʧ��");
        	req.getRequestDispatcher("cover_from.jsp").forward(req,resp);	
        }
		
		}
	
}
