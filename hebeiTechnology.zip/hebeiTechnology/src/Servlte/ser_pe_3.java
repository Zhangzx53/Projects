package Servlte;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop_cover_0;
import dao.daop_pe_3;


@WebServlet("/ser_pe_3")
public class ser_pe_3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String method = req.getParameter("method");
		if(method.equals("3-1")){
			insert_3_1(req,resp);
		}else if(method.equals("3-2")){
			insert_3_2(req,resp);
		}else if(method.equals("3-3")){
			insert_3_3(req,resp);
		}else if(method.equals("0-1")){
			insert_0t1(req,resp);
		}else if(method.equals("zhengjia")){
		zhengjia(req,resp);
		}
		
	}

	
	protected void insert_3_1(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String Name = req.getParameter("Name");
		String Sex = req.getParameter("Sex");
		String Data = req.getParameter("Data");
		String Education = req.getParameter("Education");
		String Academic = req.getParameter("Academic");
		String Graduated_from = req.getParameter("Graduated_from");
		String Major = req.getParameter("Major");
		String Title = req.getParameter("Title");
		String Talent_level = req.getParameter("Talent_level");
		String Fixed_Flow = req.getParameter("Fixed_Flow");
		String Nature_of_work = req.getParameter("Nature_of_work");
		String State = req.getParameter("State");
		String Company = req.getParameter("Company");
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_pe_3.insert_pe_3_3_1(account, Name, Sex,Data,Education,Academic,Graduated_from,Major,Title,Talent_level,Fixed_Flow,Nature_of_work,State,Company)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("huadongMenu3.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("huadongMenu3.jsp").forward(req,resp);
		}
		
	}
	
	
	
	protected void insert_3_2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String Name = req.getParameter("Name");
		String Sex = req.getParameter("Sex");
		String Data = req.getParameter("Data");
		String Education = req.getParameter("Education");
		String Academic = req.getParameter("Academic");
		String Graduated_from = req.getParameter("Graduated_from");
		String Major = req.getParameter("Major");
		String Title = req.getParameter("Title");
		String Talent_level = req.getParameter("Talent_level");
		
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_pe_3.insert_pe_3_3_2(account, Name, Sex,Data,Education,Academic,Graduated_from,Major,Title,Talent_level)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("table3-2.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("table3-2.jsp").forward(req,resp);
		}
	
	}
	protected void insert_0t1(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		String Platname = req.getParameter("Platname");
		String type = req.getParameter("type");
		String Unit_name = req.getParameter("Unit_name");
		String Administer = req.getParameter("Administer");
		String Preparer = req.getParameter("Preparer");
		String Department = req.getParameter("Department");
		String Phone = req.getParameter("Phone");
		String Telephone = req.getParameter("Telephone");
		String Mail = req.getParameter("Mail");
		String date = req.getParameter("date");
		String username = req.getParameter("username");
	
		
        
		
		if(daop_pe_3.insert_pe_0t1(Platname,type,Unit_name,Administer,Preparer,Department,Phone,Telephone,Mail,date,username)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("cover_from.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("cover_from.jsp").forward(req,resp);
		}
	
	}
	
	protected void insert_3_3(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String Name = req.getParameter("Name");
		String Sex = req.getParameter("Sex");
		String Data = req.getParameter("Data");
		String Education = req.getParameter("Education");
		String Academic = req.getParameter("Academic");
		String Graduated_from = req.getParameter("Graduated_from");
		String Major = req.getParameter("Major");
		String Title = req.getParameter("Title");
		String Talent_level = req.getParameter("Talent_level");
		String Fixed_Flow = req.getParameter("Fixed_Flow");
		String Nature_of_work = req.getParameter("Nature_of_work");
		
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_pe_3.insert_pe_3_3_3(account, Name, Sex,Data,Education,Academic,Graduated_from,Major,Title,Talent_level,Fixed_Flow,Nature_of_work)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("table3-3.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("table3-3.jsp").forward(req,resp);
		}
		
	}protected void zhengjia(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String Name = req.getParameter("Name");
		String Sex = req.getParameter("Sex");
		String Data = req.getParameter("Data");
		String Education = req.getParameter("Education");
		String Academic = req.getParameter("Academic");
		String Graduated_from = req.getParameter("Graduated_from");
		String Major = req.getParameter("Major");
		String Title = req.getParameter("Title");
		String Talent_level = req.getParameter("Talent_level");
		String Fixed_Flow = req.getParameter("Fixed_Flow");
		String Nature_of_work = req.getParameter("Nature_of_work");
		String hometown = req.getParameter("hometown");
		String beizhu = req.getParameter("beizhu");
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_pe_3.zhengjia(account, Name, Sex,Data,Education,Academic,Graduated_from,Major,Title,Talent_level,Fixed_Flow,Nature_of_work)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("add.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("add.jsp").forward(req,resp);
		}
		
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
