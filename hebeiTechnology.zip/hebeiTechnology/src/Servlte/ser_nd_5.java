package Servlte;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop_nd_5;
import dao.daop_zc_4;


@WebServlet("/ser_nd_5")
public class ser_nd_5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String method = req.getParameter("method");
		if(method.equals("5-1")){
			insert_5_1(req,resp);
		}else if(method.equals("5-2")){
			insert_5_2(req,resp);
		}else if(method.equals("5-3")){
			insert_5_3(req,resp);
		}
		
	}
	
	protected void insert_5_1(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String guojia = req.getParameter("guojia");
		String shenji = req.getParameter("shenji");
		String shiji = req.getParameter("shiji");
		String xianji = req.getParameter("xianji");
		String xiaoji1 = req.getParameter("xiaoji1");
		String renyuangongzi = req.getParameter("renyuangongzi");
		String bangongfeiyong = req.getParameter("bangongfeiyong");
		String sheshi = req.getParameter("sheshi");
		String yiqishebei = req.getParameter("yiqishebei");
		String zizhu = req.getParameter("zizhu");
		String hezuo = req.getParameter("hezuo");
		String qita = req.getParameter("qita");
		String xiaoji2 = req.getParameter("xiaoji2");
		
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_nd_5.insert_nd_5_5_1(account,guojia,shenji,shiji,xianji,xiaoji1,renyuangongzi,bangongfeiyong,sheshi,yiqishebei,zizhu,hezuo,qita,xiaoji2)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("table5-1.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("table5-1.jsp").forward(req,resp);
		}
		
	}
	
	protected void insert_5_2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String Renyuangongzi = req.getParameter("Renyuangongzi");
		String bangongfeiyong = req.getParameter("bangongfeiyong");
		String sheshi = req.getParameter("sheshi");
		String yiqishebei = req.getParameter("yiqishebei");
		String keyanxiangmu = req.getParameter("keyanxiangmu");
		String qita1 = req.getParameter("qita1");
		String xiaoji1 = req.getParameter("xiaoji1");
		String lianheyanfa = req.getParameter("lianheyanfa");
		String jishuzhuangrang = req.getParameter("jishuzhuangrang");
		String jishuzixun = req.getParameter("jishuzixun");
		String qita2 = req.getParameter("qita2");
		String xiaoji2 = req.getParameter("xiaoji2");
		
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_nd_5.insert_nd_5_5_2(account,Renyuangongzi,bangongfeiyong,sheshi,yiqishebei,keyanxiangmu,qita1,xiaoji1,lianheyanfa,jishuzhuangrang,jishuzixun,qita2,xiaoji2)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("table5-2.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("table5-2.jsp").forward(req,resp);
		}
		
	}
	
	protected void insert_5_3(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		req.setCharacterEncoding("utf-8");
		String keji = req.getParameter("keji");
		String renyuan = req.getParameter("renyuan");
		String jijian = req.getParameter("jijian");
		String yiqi = req.getParameter("yiqi");
		String yanfa = req.getParameter("yanfa");
		String richang = req.getParameter("richang");
		String qita = req.getParameter("qita");
		
		Cookie[] cookies=req.getCookies();
		String account = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("account")){
                	account=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
		
		if(daop_nd_5.insert_nd_5_5_3(account,keji,renyuan,jijian,yiqi,yanfa,richang,qita)){
			req.setAttribute("message", "����ɹ�");
			req.getRequestDispatcher("table5-3.jsp").forward(req,resp);
		}else{
			req.setAttribute("message", "����ʧ��");
			req.getRequestDispatcher("table5-3.jsp").forward(req,resp);
		}
		
	}
	


}
