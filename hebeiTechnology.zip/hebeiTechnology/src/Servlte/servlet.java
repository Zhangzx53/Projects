package Servlte;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.*;
import javaweb.*;


@WebServlet("/servlet")
public class servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if ("2t1".equals(method)) 
	{
		add2t1(request, response);
	}else if("2t2".equals(method)) 
	{
		add2t2(request, response);
	}else if("2t3".equals(method)) 
	{
		add2t3(request, response);
	}else if("2t4".equals(method)) 
	{
		add2t4(request, response);
	}else if("2t5".equals(method)) 
	{
		add2t5(request, response);
	}
	else if("1t1".equals(method)) 
	{
		add1t1(request, response);
	}
	}

	private void add2t1(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
		String no=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");	
		String fangxiang=new String (request.getParameter("fangxiang").getBytes("iso-8859-1"),"utf-8");
		String neirong=new String (request.getParameter("neirong").getBytes("iso-8859-1"),"utf-8");
		fa f=new fa(no,fangxiang,neirong);
		if(daoa.add2t1(f))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("table2-1.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("table2-1.jsp").forward(request,response);
		}
	}
	
	private void add2t2(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	
		response.setCharacterEncoding("utf-8");
		String no=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");	
		String name=new String (request.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		
		fa f=new fa(no,name);
		if(daoa.add2t2(f))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("table2-2.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("table2-2.jsp").forward(request,response);
		}
	}
	
	private void add2t3(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		String no=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");
		String name=new String (request.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		String dengji=new String (request.getParameter("dengji").getBytes("iso-8859-1"),"utf-8");
		String bumen=new String (request.getParameter("bumen").getBytes("iso-8859-1"),"utf-8");
		fa f=new fa(no,name,dengji,bumen);
		if(daoa.add2t3(f))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("table2-3.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("table2-3.jsp").forward(request,response);
		}
	}
	private void add2t4(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		String no=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");
		String name=new String (request.getParameter("name").getBytes("iso-8859-1"),"utf-8");
		String danwei=new String (request.getParameter("danwei").getBytes("iso-8859-1"),"utf-8");

		fa f=new fa(no,name,danwei);
		if(daoa.add2t4(f))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("table2-4.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("table2-4.jsp").forward(request,response);
		}
	}
	private void add2t5(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		response.setCharacterEncoding("utf-8");
		String no=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");
		String xiangmu=new String (request.getParameter("xiangmu").getBytes("iso-8859-1"),"utf-8");
		String neirong=new String (request.getParameter("neirong").getBytes("iso-8859-1"),"utf-8");

		fa f=new fa(no,xiangmu,neirong);
		if(daoa.add2t5(f))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("table2-5.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("table2-5.jsp").forward(request,response);
		}
	}
	private void add1t1(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		String a=new String (request.getParameter("no").getBytes("iso-8859-1"),"utf-8");
		String b=new String (request.getParameter("riqi").getBytes("iso-8859-1"),"utf-8");
		String c=new String (request.getParameter("wenhao").getBytes("iso-8859-1"),"utf-8");
		String d=new String (request.getParameter("lingyu").getBytes("iso-8859-1"),"utf-8");
		String e=new String (request.getParameter("jibei").getBytes("iso-8859-1"),"utf-8");
		String f=new String (request.getParameter("suozaidi").getBytes("iso-8859-1"),"utf-8");
		String g=new String (request.getParameter("faren").getBytes("iso-8859-1"),"utf-8");
		String h=new String (request.getParameter("jianshe").getBytes("iso-8859-1"),"utf-8");
		String i=new String (request.getParameter("gongjian").getBytes("iso-8859-1"),"utf-8");
		String j=new String (request.getParameter("hangyeo").getBytes("iso-8859-1"),"utf-8");
		String k=new String (request.getParameter("hangyet").getBytes("iso-8859-1"),"utf-8");
		String l=new String (request.getParameter("hangyes").getBytes("iso-8859-1"),"utf-8");
		String m=new String (request.getParameter("xuekeo").getBytes("iso-8859-1"),"utf-8");
		String n=new String (request.getParameter("xueket").getBytes("iso-8859-1"),"utf-8");
		String o=new String (request.getParameter("xuekes").getBytes("iso-8859-1"),"utf-8");
		String p=new String (request.getParameter("dname").getBytes("iso-8859-1"),"utf-8");
		String q=new String (request.getParameter("daima").getBytes("iso-8859-1"),"utf-8");
		String r=new String (request.getParameter("danleixing").getBytes("iso-8859-1"),"utf-8");
		String s=new String (request.getParameter("gongdanwei").getBytes("iso-8859-1"),"utf-8");
		String t=new String (request.getParameter("zanname").getBytes("iso-8859-1"),"utf-8");
		String u=new String (request.getParameter("wangzi").getBytes("iso-8859-1"),"utf-8");
		String v=new String (request.getParameter("tongdizhi").getBytes("iso-8859-1"),"utf-8");
		String w=new String (request.getParameter("youbian").getBytes("iso-8859-1"),"utf-8");
		String xx=new String (request.getParameter("yuanname").getBytes("iso-8859-1"),"utf-8");
		String y=new String (request.getParameter("sex").getBytes("iso-8859-1"),"utf-8");
		String z=new String (request.getParameter("niamyue").getBytes("iso-8859-1"),"utf-8");
		String aa=new String (request.getParameter("zhicheng").getBytes("iso-8859-1"),"utf-8");
		String bb=new String (request.getParameter("zhuanye").getBytes("iso-8859-1"),"utf-8");
		String cc=new String (request.getParameter("xueli").getBytes("iso-8859-1"),"utf-8");
		String dd=new String (request.getParameter("xuewei").getBytes("iso-8859-1"),"utf-8");
		String ee=request.getParameter("dianhua");
		String ff=request.getParameter("shuoji");
		String gg=new String (request.getParameter("youxiang").getBytes("iso-8859-1"),"utf-8");
        System.out.println(b);
		fa1 x=new fa1(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,xx,y,z,aa,bb,cc,dd,ee,ff,gg);
		if(dao1.add1t1(x))
		{
			request.setAttribute("message", "���ӳɹ�");
			request.getRequestDispatcher("basic_information.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("message", "����ʧ��");
			request.getRequestDispatcher("basic_information.jsp").forward(request,response);
		}
	}
}
