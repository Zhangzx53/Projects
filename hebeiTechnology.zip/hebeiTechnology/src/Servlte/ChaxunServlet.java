package Servlte;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DBUtil.DBUtil;
@WebServlet("/ChaxunServlet")
public class ChaxunServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String sql = "select * from 1t1";
		int num = 0;
		if(req.getParameter("diaochaname")!=null&&!req.getParameter("name").equals("")){
			String diaochaname=new String (req.getParameter("diaochaname").getBytes("iso-8859-1"),"utf-8");
			String name=new String (req.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			
			if(num==0){
				sql = sql + " where " + diaochaname +" = '" + name + "'";
			}else{
				sql = sql + " and  " + diaochaname +" = '" + name + "'";
			}
			num++;
		}
		if(req.getParameter("diaochaname1")!=null&&!req.getParameter("name1").equals("")){
			
			String diaochaname1=new String (req.getParameter("diaochaname1").getBytes("iso-8859-1"),"utf-8");
			String name1=new String (req.getParameter("name1").getBytes("iso-8859-1"),"utf-8");
			
			if(num==0){
				sql = sql + " where " + diaochaname1 +" = '" + name1 + "'";
			}else{
				sql = sql + " and  " + diaochaname1 +" = '" + name1 + "'";
			}
			num++;
		}
		if(req.getParameter("diaochaname2")!=null&&!req.getParameter("name2").equals("")){
			String diaochaname2=new String (req.getParameter("diaochaname2").getBytes("iso-8859-1"),"utf-8");
			String name2=new String (req.getParameter("name2").getBytes("iso-8859-1"),"utf-8");
			if(num==0){
				sql = sql + " where " + diaochaname2 +" = '" + name2 + "'";
			}else{
				sql = sql + " and  " + diaochaname2 +" = '" + name2 + "'";
			}
			num++;
		}
		if(req.getParameter("diaochaname3")!=null&&!req.getParameter("name3").equals("")){
			String diaochaname3=new String (req.getParameter("diaochaname3").getBytes("iso-8859-1"),"utf-8");
			String name3=new String (req.getParameter("name3").getBytes("iso-8859-1"),"utf-8");

			if(num==0){
				sql = sql + " where " + diaochaname3 +" = '" + name3 + "'";
			}else{
				sql = sql + " and  " + diaochaname3 +" = '" + name3 + "'";
			}
			num++;
		}
		if(req.getParameter("diaochaname4")!=null&&!req.getParameter("name4").equals("")){
			String diaochaname4=new String (req.getParameter("diaochaname4").getBytes("iso-8859-1"),"utf-8");
			String name4=new String (req.getParameter("name4").getBytes("iso-8859-1"),"utf-8");

			if(num==0){
				sql = sql + " where " + diaochaname4 +" = '" + name4 + "'";
			}else{
				sql = sql + " and  " + diaochaname4 +" = '" + name4 + "'";
			}
			num++;
		}
		if(num==0){
			req.setAttribute("message", "�����������ڽ��в�ѯ");
		   	req.getRequestDispatcher("search_in_detail.jsp").forward(req,resp);
		}else{
			System.out.println(sql);
			List<String> list = new ArrayList<>();
			Connection conn = DBUtil.getConn();
			Statement state = null;
			ResultSet rs = null;
			try {
				state = conn.createStatement();
				rs = state.executeQuery(sql);
				String x=null;
				while (rs.next()) {
					String Platname = rs.getString("no");
					x=new String(Platname);
					list.add(x);
					System.out.println(list.get(0));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(rs, state, conn);
			}
			if(list.size()==0){
				req.setAttribute("message", "δ��ѯ���������");
			   	req.getRequestDispatcher("search_in_detail.jsp").forward(req,resp);
			}else{
				String [] plat_na = new String[list.size()];
				for(int i=0;i<list.size();i++){
					plat_na[i] = list.get(i);
				}
				req.setAttribute("plat_na", plat_na);
			   	req.getRequestDispatcher("show_plat_na.jsp").forward(req,resp); 
			}
		}
	}

}
