package Servlte;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.*;
import javaweb.*;


@WebServlet("/servletxinxi")
public class servletxinxi extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if ("xinxi".equals(method)) 
	{
		xinxi(request, response);
	}
	}

	private void xinxi(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		// TODO Auto-generated method stub
		
			req.setCharacterEncoding("utf-8");
			String pingtainame=new String (req.getParameter("pingtainame").getBytes("iso-8859-1"),"utf-8");	
			String yituodanwei=new String (req.getParameter("yituodanwei").getBytes("iso-8859-1"),"utf-8");
			String pingtaijibie=new String (req.getParameter("pingtaijibie").getBytes("iso-8859-1"),"utf-8");
			String pingtaileixing=new String (req.getParameter("pingtaileixing").getBytes("iso-8859-1"),"utf-8");
			String pizhunwenhao=new String (req.getParameter("pizhunwenhao").getBytes("iso-8859-1"),"utf-8");
			String pizhunriqi=new String (req.getParameter("pizhunriqi").getBytes("iso-8859-1"),"utf-8");
			String username=new String (req.getParameter("username").getBytes("iso-8859-1"),"utf-8");
			
		
		
			xinxi maintenance = new xinxi(pingtainame,yituodanwei,pingtaijibie,pingtaileixing,pizhunwenhao,pizhunriqi,username);		
			if(daoxinxi.maintenanceadd(maintenance)) {
				req.setAttribute("message", "����ɹ�");
				req.getRequestDispatcher("index.jsp").forward(req,resp);
			} else {
				req.setAttribute("message", "����ʧ��");
				req.getRequestDispatcher("maintenance.jsp").forward(req,resp);
			}
		}
}
