package Servlte;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.*;
import javaweb.*;
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if ("login".equals(method)) 
	{
		login(request, response);
	}else if("zhuce".equals(method))
	{
		zhuce(request, response);
	}
	}
	/**
	 * ͨ������  ��¼����
	 * 
	 * @param req
	 * @param resp
	 * @throws IOException
	 * @throws ServletException 
	 */
	private void login(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		HttpSession session = req.getSession();
		req.setCharacterEncoding("utf-8");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		user user = Userdao.getUserByName(username,password);
	
		if(user.getNumber()==0) {
			Userdao.setnumber(username);
			session.setAttribute("username", username);
			req.setAttribute("message", "�״ε�½��");
			req.getRequestDispatcher("xinxi.jsp").forward(req,resp);
		} else if(user.getNumber()!=0)
		{
			session.setAttribute("username", username);


			req.getRequestDispatcher("index.jsp").forward(req,resp);
		}
	}
	
	private void zhuce(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		
		req.setCharacterEncoding("utf-8");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		user f=new user(username,password);
		if(Userdao.zhuce(f)) {
			req.setAttribute("message", "");
			req.getRequestDispatcher("DengLu.jsp").forward(req,resp);
		} else {
			
			req.setAttribute("message", "ע��ʧ��");
			req.getRequestDispatcher("zhuce.jsp").forward(req,resp);
		}
	}
}

