package Servlte;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.daop_zc_4;


@WebServlet("/ser_zc_4")
public class ser_zc_4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String method = req.getParameter("method");
		if(method.equals("4-1")){
			insert_4_1(req,resp);
		}else if(method.equals("4-2")){
			insert_4_2(req,resp);
		}
	}
		
		
		
		protected void insert_4_1(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
			req.setCharacterEncoding("utf-8");
			String Area_year_all = req.getParameter("Area_year_all");
			String Keyan_year_all = req.getParameter("Keyan_year_all");
			String Bangong_year_all = req.getParameter("Bangong_year_all");
			String Else_year_all = req.getParameter("Else_year_all");
			String Area_year_add = req.getParameter("Area_year_add");
			String Keyan_year_add = req.getParameter("Keyan_year_add");
			String Bangong_year_add = req.getParameter("Bangong_year_add");
			String Else_year_add = req.getParameter("Else_year_add");
			String Area_year_reduce = req.getParameter("Area_year_reduce");
			String Keyan_year_reduce = req.getParameter("Keyan_year_reduce");
			String Bangong_year_reduce = req.getParameter("Bangong_year_reduce");
			String Else_year_reduce = req.getParameter("Else_year_reduce");
			
			Cookie[] cookies=req.getCookies();
			String account = "";
	        if(cookies!=null&&cookies.length>0){
	            for(Cookie c:cookies){
	                if(c.getName().equals("account")){
	                	account=URLDecoder.decode(c.getValue(), "utf-8");
	                }
	            }
	        }
			
			if(daop_zc_4.insert_zc_4_4_1(account, Area_year_all, Keyan_year_all,Bangong_year_all,Else_year_all,Area_year_add,Keyan_year_add,Bangong_year_add,Else_year_add,Area_year_reduce,Keyan_year_reduce,Bangong_year_reduce,Else_year_reduce)){
				req.setAttribute("message", "����ɹ�");
				req.getRequestDispatcher("huadongMenu4.jsp").forward(req,resp);
			}else{
				req.setAttribute("message", "����ʧ��");
				req.getRequestDispatcher("huadongMenu4.jsp").forward(req,resp);
			}
		
		}
		
		
		protected void insert_4_2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
			req.setCharacterEncoding("utf-8");
			String Yiqi_year_all = req.getParameter("Yiqi_year_all");
			String Yiqi20_year_all = req.getParameter("Yiqi20_year_all");
			String yuanzhi_year_all = req.getParameter("yuanzhi_year_all");
			String yuanzhi20_year_all = req.getParameter("yuanzhi20_year_all");
			String Yiqi_year_add = req.getParameter("Yiqi_year_add");
			String Yiqi20_year_add = req.getParameter("Yiqi20_year_add");
			String yuanzhi_year_add = req.getParameter("yuanzhi_year_add");
			String yuanzhi20_year_add = req.getParameter("yuanzhi20_year_add");
			String Yiqi_year_reduce = req.getParameter("Yiqi_year_reduce");
			String Yiqi20_year_reduce = req.getParameter("Yiqi20_year_reduce");
			String yuanzhi_year_reduce = req.getParameter("yuanzhi_year_reduce");
			String yuanzhi20_year_reduce = req.getParameter("yuanzhi20_year_reduce");
			
			Cookie[] cookies=req.getCookies();
			String account = "";
	        if(cookies!=null&&cookies.length>0){
	            for(Cookie c:cookies){
	                if(c.getName().equals("account")){
	                	account=URLDecoder.decode(c.getValue(), "utf-8");
	                }
	            }
	        }
			
			if(daop_zc_4.insert_zc_4_4_2(account, Yiqi_year_all, Yiqi20_year_all,yuanzhi_year_all,yuanzhi20_year_all,Yiqi_year_add,Yiqi20_year_add,yuanzhi_year_add,yuanzhi20_year_add,Yiqi_year_reduce,Yiqi20_year_reduce,yuanzhi_year_reduce,yuanzhi20_year_reduce)){
				req.setAttribute("message", "����ɹ�");
				req.getRequestDispatcher("table4-2.jsp").forward(req,resp);
			}else{
				req.setAttribute("message", "����ʧ��");
				req.getRequestDispatcher("table4-2.jsp").forward(req,resp);
			}
			
		}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
