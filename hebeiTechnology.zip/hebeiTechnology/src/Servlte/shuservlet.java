package Servlte;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop_search;
import javaweb.plat;
import javaweb.plat_1;
@WebServlet("/shuservlet")
public class shuservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException,NullPointerException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=UTF-8");
		List<plat> list = daop_search.get_plat();
		String [] node_0;
		int length = 0;
		if(req.getParameterValues("lv3_1Check")!=null){
			node_0 = req.getParameterValues("lv3_1Check");
			length = length + node_0.length;
		}
		if(req.getParameterValues("lv3_2Check")!=null){
			node_0 = req.getParameterValues("lv3_2Check");
			length = length + node_0.length;
		}
		if(req.getParameterValues("lv3_3Check")!=null){
			node_0 = req.getParameterValues("lv3_3Check");
			length = length + node_0.length;
		}
		if(length!=0){
			String [] node = new String[length];
			int len = 0;
			int k;
			if(req.getParameterValues("lv3_1Check")!=null){
				node_0 = req.getParameterValues("lv3_1Check");
				k = len;
				for(int i = len;i<node_0.length;i++){
					node[len] = node_0[i-k];
					len++;
				}
			}
			if(req.getParameterValues("lv3_2Check")!=null){
				node_0 = req.getParameterValues("lv3_2Check");
				k = len;
				for(int i = 0;i<node_0.length;i++){
					node[i+k] = node_0[i];
					len++;
				}
			}
			if(req.getParameterValues("lv3_3Check")!=null){
				node_0 = req.getParameterValues("lv3_3Check");
				k = len;
				for(int i = 0;i<node_0.length;i++){
					node[i+k] = node_0[i];
					len++;
				}
			}
			
			System.out.println(len);
			
			int plat_len = 0;
			String [] plat_name = new String[list.size()];
			for(int i=0;i<list.size();i++){
				for(int j=0;j<node.length;j++){
				if(list.get(i).riqi.substring(0,6).equals(node[j])){
					plat_name[plat_len] = list.get(i).no;
					plat_len++;
				}
			}
			}
			
			if(plat_len!=0){
			String [] plat_na = new String[plat_len];
			for(int i=0;i<plat_len;i++){
				plat_na[i] = plat_name[i];//�õ�����Ӧ������Ӧ�����е�ƽ̨����
			}
			req.setAttribute("plat_na", plat_na);
		   	req.getRequestDispatcher("shuzhuang.jsp").forward(req,resp); 
			}else{
				req.setAttribute("message", "δ��ѯ���õ�����������Ϣ");
			   	req.getRequestDispatcher("shuzhuang.jsp").forward(req,resp); 
			}
		}else{
			req.setAttribute("message", "��ѡ�е������ѯ");
		   	req.getRequestDispatcher("shuzhuang.jsp").forward(req,resp);
		}
		
	}

}
