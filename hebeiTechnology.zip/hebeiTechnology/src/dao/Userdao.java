package dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import DBUtil.DBUtil;
import javaweb.fa;
import javaweb.user;
public class Userdao {

		

	public static user getUserByName(String username, String password) {
		String sql = "select * from user where username ='" + username + "' and password ='" + password + "'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		user user = null;
		
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				int id = rs.getInt("id");
				String username1 = rs.getString("username");
				String password1 = rs.getString("password");
				int number = rs.getInt("number");
				user = new user(id, username1,password1,number);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		
		return user;
	}
	public static boolean setnumber(String username) {
		String sql = "update user set number='" +"1"
		+ "' where username='" + username + "'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;

		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);//ִ��sql��䣬������ִ�гɹ�sql�������
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
	public static boolean zhuce(user f) {
		String sql = "insert into user(username,password) values('" + f.getUsername() + "','" + f.getPassword() +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean user = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			user = true;
		}
		return user;
	}	
	}

	