package dao;
import java.sql.Connection;
import java.sql.Statement;

import DBUtil.DBUtil;
public class daop_cover_0 {

	public static boolean insert_cover_0(String Platname,String type,String Unit_name,String Administer,String Preparer,String Department,String Phone,String Telephone,String Mail,String date){
		
		String sql = "insert into 0t1('" + Platname + "','" + type  +"','" + Unit_name  +"','" + Administer  +"','" + Preparer  +"','" + Department  +"','" + Phone  +"','" + Telephone  +"','" + Mail  +"','" + date  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
		
	}
	
	
	
}
