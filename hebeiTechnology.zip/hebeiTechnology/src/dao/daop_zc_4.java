package dao;

import java.sql.Connection;
import java.sql.Statement;

import DBUtil.DBUtil;
public class daop_zc_4 {

	public static boolean insert_zc_4_4_1(String account,String Area_year_all,String Keyan_year_all,String Bangong_year_all,String Else_year_all,String Area_year_add,String Keyan_year_add,String Bangong_year_add,String Else_year_add,String Area_year_reduce,String Keyan_year_reduce,String Bangong_year_reduce,String Else_year_reduce) {
		String sql = "insert into 4t1 values('" + account + "','" + Area_year_all  +"','" + Keyan_year_all  +"','" + Bangong_year_all  +"','" + Else_year_all  +"','" + Area_year_add  +"','" + Keyan_year_add  +"','" + Bangong_year_add  +"','" + Else_year_add  +"','" + Area_year_reduce  +"','" + Keyan_year_reduce  +"','" + Bangong_year_reduce  +"','" + Else_year_reduce  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
	public static boolean insert_zc_4_4_2(String account,String Yiqi_year_all,String Yiqi20_year_all,String yuanzhi_year_all,String yuanzhi20_year_all,String Yiqi_year_add,String Yiqi20_year_add,String yuanzhi_year_add,String yuanzhi20_year_add,String Yiqi_year_reduce,String Yiqi20_year_reduce,String yuanzhi_year_reduce,String yuanzhi20_year_reduce) {
		String sql = "insert into 4t2 values('" + account + "','" + Yiqi_year_all  +"','" + Yiqi20_year_all  +"','" + yuanzhi_year_all  +"','" + yuanzhi20_year_all  +"','" + Yiqi_year_add  +"','" + Yiqi20_year_add  +"','" + yuanzhi_year_add  +"','" + yuanzhi20_year_add  +"','" + Yiqi_year_reduce  +"','" + Yiqi20_year_reduce  +"','" + yuanzhi_year_reduce  +"','" + yuanzhi20_year_reduce  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
}
