package dao;
import java.sql.Connection;
import java.sql.Statement;

import DBUtil.DBUtil;
public class daop_nd_5 {

	public static boolean insert_nd_5_5_1(String account,String guojia,String shenji,String shiji,String xianji,String xiaoji1,String renyuangongzi,String bangongfeiyong,String sheshi,String yiqishebei,String zizhu,String hezuo,String qita,String xiaoji2) {
		String sql = "insert into 5t1 values('" + account + "','" + guojia + "','" + shenji  +"','" + shiji  +"','" + xianji  +"','" + xiaoji1  +"','" + renyuangongzi  +"','" + bangongfeiyong  +"','" + sheshi  +"','" + yiqishebei  +"','" + zizhu  +"','" + hezuo  +"','" + qita  +"','" + xiaoji2  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
	public static boolean insert_nd_5_5_2(String account,String Renyuangongzi,String bangongfeiyong,String sheshi,String yiqishebei,String keyanxiangmu,String qita1,String xiaoji1,String lianheyanfa,String jishuzhuangrang,String jishuzixun,String qita2,String xiaoji2) {
		String sql = "insert into 5t2 values('" + account + "','" + Renyuangongzi  +"','" + bangongfeiyong  +"','" + sheshi  +"','" + yiqishebei  +"','" + keyanxiangmu  +"','" + qita1  +"','" + xiaoji1  +"','" + lianheyanfa  +"','" + jishuzhuangrang  +"','" + jishuzixun  +"','" + qita2  +"','" + xiaoji2  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
	public static boolean insert_nd_5_5_3(String account,String Renyuangongzi,String bangongfeiyong,String sheshi,String yiqishebei,String keyanxiangmu,String qita1,String xiaoji1) {
		String sql = "insert into 5t3 values('" + account + "','" + Renyuangongzi  +"','" + bangongfeiyong  +"','" + sheshi  +"','" + yiqishebei  +"','" + keyanxiangmu  +"','" + qita1  +"','" + xiaoji1  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
}
