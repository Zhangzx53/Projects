package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import DBUtil.DBUtil;
import javaweb.Showlist;



public class daocha {
	public static List<Showlist> showlist(String tiaojian1,String tiaojian2) {
		String sql = "select Platname,Phone,Preparer,date from 0t1 "
				+ "where " + tiaojian1 + " ='" + tiaojian2 + "'";
		System.out.println(sql);
		Connection conn = DBUtil.getConn();
		List<Showlist> result=new ArrayList<>();
		Statement state = null;
		ResultSet rs = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String pingtainame = rs.getString("Platname");
				String pizhunriqi = rs.getString("Phone");
				String ren_name = rs.getString("Preparer");
				String tianbiaoriqi = rs.getString("date");
				Showlist show = new Showlist(pingtainame,pizhunriqi,ren_name,tianbiaoriqi);
				result.add(show);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return result;
	}
}
