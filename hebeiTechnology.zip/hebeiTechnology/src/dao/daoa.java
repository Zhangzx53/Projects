package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DBUtil.DBUtil;
import javaweb.fa;



//���ݷ��ʲ㣺
@SuppressWarnings("unused")
public class daoa {
	public static boolean add2t1(fa x) {
		String sql = "insert into 2t1(no,fangxiang,neirong) values('" + x.getNo() + "','" + x.getFangxiang() +"','" + x.getNeirong() +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	

		public static boolean add2t2(fa x) {
			String sql = "insert into 2t2(no,name) values('" + x.getNo() + "','" + x.getName() +"')";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			boolean f = false;
			int a = 0;
			try {
				state = conn.createStatement();
				a = state.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(state, conn);
			}
			
			if (a > 0) {
				f = true;
			}
			return f;
		}	
		
		public static boolean add2t3(fa x) {
			String sql = "insert into 2t3(no,name,dengji,bumen) values('" + x.getNo() + "','" + x.getName() +"','" + x.getNeirong() +"','" + x.getFangxiang() +"')";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			boolean f = false;
			int a = 0;
			try {
				state = conn.createStatement();
				a = state.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(state, conn);
			}
			
			if (a > 0) {
				f = true;
			}
			return f;
		}
		public static boolean add2t4(fa x) {
			String sql = "insert into 2t4(no,name,danwei) values('" + x.getNo() + "','" + x.getFangxiang() +"','" + x.getNeirong() +"')";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			boolean f = false;
			int a = 0;
			try {
				state = conn.createStatement();
				a = state.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(state, conn);
			}
			
			if (a > 0) {
				f = true;
			}
			return f;
		}
		public static boolean add2t5(fa x) {
			String sql = "insert into 2t5(no,xiangmu,neirong) values('" + x.getNo() + "','" + x.getFangxiang() +"','" + x.getNeirong() +"')";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			boolean f = false;
			int a = 0;
			try {
				state = conn.createStatement();
				a = state.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(state, conn);
			}
			
			if (a > 0) {
				f = true;
			}
			return f;
		}
}
