package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBUtil;

import javaweb.ex_1;
import javaweb.plat;
import javaweb.plat_1;

public class daop_search {

	


	
	//�õ�plat��Ϣ
	public static List<plat> get_plat() {
		List<plat> list = new ArrayList<plat>();
		String sql = "select * from 1t1";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		plat s = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String Platname = rs.getString("no");
				String PlatId = rs.getString("riqi");
				s=new plat(Platname,PlatId);
				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return list;
	}
	
	
	
				
				
				
				//�õ�plat��Ϣ
				public static plat_1 get_plat_search(String name) {
					String sql = "select * from 1t1 where no = '" + name + "'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					plat_1 s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							String Platname = rs.getString("no");
							String Field = rs.getString("riqi");
							String Level = rs.getString("wenhao");
							String Unit_class = rs.getString("lingyu");
							String if_jjj = rs.getString("jibei");
							String Organ_form = rs.getString("suozaidi");
							s=new plat_1(Platname,Field,Level,Unit_class,if_jjj,Organ_form);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return s;
				}
				
				
				public static ex_1 getex_1(String name) {
					String sql = "select * from 0t1 where no ='" + name + "'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					ex_1 s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							String PlatId = rs.getString("riqi");
							String Platname = rs.getString("no");
							String Approvaldate = rs.getString("wenhao");
							String ApprovalId = rs.getString("lingyu");
							String Field = rs.getString("jibei");
							String Level = rs.getString("suozaidi");
							String Place = rs.getString("faren");
							String Organ_form = rs.getString("jianshe");
							String Major_industries1 = rs.getString("gongjian");
							String Major_industries2 = rs.getString("hangyeo");
							String Major_industries3 = rs.getString("hangyet");
							String Main_disciplines1 = rs.getString("hangyes");
							String Main_disciplines2 = rs.getString("xuekeo");
							String Main_disciplines3 = rs.getString("xueket");
							String Unit_name = rs.getString("xuekes");
							String Unit_id = rs.getString("dname");
							String Unit_user = rs.getString("daima");
							String Unit_number = rs.getString("danleixing");
							String Unit_class = rs.getString("gongdanwei");
							String if_jjj = rs.getString("zanname");
							String Construction_unit = rs.getString("wangzi");
							String Plat_name = rs.getString("tongdizhi");
							String Website = rs.getString("youbian");
							String Mail_address = rs.getString("yuanname");
							String Postal_code = rs.getString("sex");
							String Plat_user_name = rs.getString("niamyue");
							String Plat_user_sex = rs.getString("zhicheng");
							String Plat_user_birth = rs.getString("zhuanye");
							String Plat_user_title = rs.getString("xueli");
							String Plat_user_major = rs.getString("xuewei");
							String Plat_user_education = rs.getString("dianhua");
							String Plat_user_academic = rs.getString("shuoji");
							String Plat_user_phone = rs.getString("youxiang");
							String Plat_user_telephone = rs.getString("youxiang");
							String Plat_user_mail = rs.getString("youxiang");
							s=new ex_1(PlatId,Platname,Approvaldate,ApprovalId,Field,Level,Place,Organ_form,Major_industries1,
									Major_industries2,Major_industries3,Main_disciplines1,Main_disciplines2,Main_disciplines3,Unit_name,
									Unit_id,Unit_user,Unit_number,Unit_class,if_jjj,Construction_unit,Plat_name,Website,Mail_address,Postal_code,
									Plat_user_name,Plat_user_sex,Plat_user_birth,Plat_user_title,Plat_user_major,Plat_user_education,
									Plat_user_academic,Plat_user_phone,Plat_user_telephone,Plat_user_mail);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return s;
				}
				
				
				
}
