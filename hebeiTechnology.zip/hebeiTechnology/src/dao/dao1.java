package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DBUtil.DBUtil;
import javaweb.fa1;



//���ݷ��ʲ㣺
@SuppressWarnings("unused")
public class dao1 {
	public static boolean add1t1(fa1 x) {
		String sql = "insert into 1t1(no,riqi,wenhao,lingyu,jibei,suozaidi,faren,jianshe,gongjian,hangyeo,hangyet,hangyes,xuekeo,xueket,xuekes,dname,daima,danleixing,gongdanwei,zanname,wangzi,tongdizhi,youbian,yuanname,sex,niamyue,zhicheng,zhuanye,xueli,xuewei,dianhua,shuoji,youxiang) values('" + x.getNo() + "','" + x.getRiqi() +"','" + x.getWenhao() +"','" + x.getLingyu() +"','" + x.getJibei() +"','" + x.getSuozaidi() +"','" + x.getFaren() +"','" + x.getJianshe() +"','" + x.getGongjian() +"','" + x.getHangyeo() +"','" + x.getHangyet() +"','" + x.getHangyes() +"','" + x.getXuekeo() +"','" + x.getXueket() +"','" + x.getXuekes() +"','" + x.getDname() +"','" + x.getDaima() +"','" + x.getDanleixing() +"','" + x.getGongdanwei() +"','" + x.getZanname() +"','" + x.getWangzi() +"','" + x.getTongdizhi() +"','" + x.getYoubian() +"','" + x.getYuanname() +"','" + x.getSex() +"','" + x.getNiamyue() +"','" + x.getZhicheng() +"','" + x.getZhuanye() +"','" + x.getXueli() +"','" + x.getXuewei() +"','" + x.getDianhua() +"','" + x.getShuoji() +"','" + x.getYouxiang() +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}

	public static fa1 getex_1(String name) {
		String sql = "select * from 1t1 where no ='" + name + "'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		fa1 s = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String PlatId = rs.getString("no");
				String Platname = rs.getString("riqi");
				String Approvaldate = rs.getString("wenhao");
				String ApprovalId = rs.getString("lingyu");
				String Field = rs.getString("jibei");
				String Level = rs.getString("suozaidi");
				String Place = rs.getString("faren");
				String Organ_form = rs.getString("jianshe");
				String Major_industries1 = rs.getString("gongjian");
				String Major_industries2 = rs.getString("hangyeo");
				String Major_industries3 = rs.getString("hangyet");
				String Main_disciplines1 = rs.getString("hangyes");
				String Main_disciplines2 = rs.getString("xuekeo");
				String Main_disciplines3 = rs.getString("xueket");
				String Unit_name = rs.getString("xuekes");
				String Unit_id = rs.getString("dname");
				String Unit_user = rs.getString("daima");
				String Unit_number = rs.getString("danleixing");
				String Unit_class = rs.getString("gongdanwei");
				String if_jjj = rs.getString("zanname");
				String Construction_unit = rs.getString("wangzi");
				String Plat_name = rs.getString("tongdizhi");
				String Website = rs.getString("youbian");
				String Mail_address = rs.getString("yuanname");
				String Postal_code = rs.getString("sex");
				String Plat_user_name = rs.getString("niamyue");
				String Plat_user_sex = rs.getString("zhicheng");
				String Plat_user_birth = rs.getString("zhuanye");
				String Plat_user_title = rs.getString("xueli");
				String Plat_user_major = rs.getString("xuewei");
				String Plat_user_education = rs.getString("dianhua");
				String Plat_user_academic = rs.getString("shuoji");
				String Plat_user_phone = rs.getString("youxiang");
		
				s=new fa1(PlatId,Platname,Approvaldate,ApprovalId,Field,Level,Place,Organ_form,Major_industries1,
						Major_industries2,Major_industries3,Main_disciplines1,Main_disciplines2,Main_disciplines3,Unit_name,
						Unit_id,Unit_user,Unit_number,Unit_class,if_jjj,Construction_unit,Plat_name,Website,Mail_address,Postal_code,
						Plat_user_name,Plat_user_sex,Plat_user_birth,Plat_user_title,Plat_user_major,Plat_user_education,
						Plat_user_academic,Plat_user_phone);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return s;
	}
	
	
	
}


	