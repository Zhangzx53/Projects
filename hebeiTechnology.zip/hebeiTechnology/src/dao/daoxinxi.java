package dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import DBUtil.DBUtil;
import javaweb.Show;
import javaweb.xinxi;
public class daoxinxi {
	public static boolean maintenanceadd(xinxi maintenance) {
		String sql = "insert into maintenance(pingtainame,yituodanwei,pingtaijibie,pingtaileixing,pizhunwenhao,pizhunriqi,username) values('" + maintenance.getPingtainame() + "','" + maintenance.getYituodanwei() + "','" + maintenance.getPingtaijibie() + "','" + maintenance.getPingtaileixing()+ "','" + maintenance.getPizhunwenhao()+ "','" + maintenance.getPizhunriqi() + "','" + maintenance.getUsername() + "')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;	
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		if (a > 0) {
			f = true;		
		}
		return f;
	}
	
	public static List<Show> niandu(String a, String b) {
		String sql = "select pingtainame,Preparer,pingtaijibie,pingtaileixing,pizhunriqi,date from maintenance "
				+ "join 0t1 on maintenance.username = 0t1.username "
				+ "where "+b+" ='" + a + "'";
		System.out.println(sql);
		Connection conn = DBUtil.getConn();
		List<Show> result=new ArrayList<>();
		Statement state = null;
		ResultSet rs = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String pingtainame = rs.getString("pingtainame");
				String ren_name = rs.getString("Preparer");
				
				String pingtaijibie = search(rs.getString("pingtaijibie"));
				
				String pingtaileixing = rs.getString("pingtaileixing");
				
				String pizhunriqi = rs.getString("pizhunriqi");
				String date = rs.getString("date");
				Show show = new Show(pingtainame,ren_name,pingtaijibie,pingtaileixing,pizhunriqi,date);
				result.add(show);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		return result;
	}

	private static String search(String string) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
