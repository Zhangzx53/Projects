package dao;
import java.sql.Connection;
import java.sql.Statement;

import DBUtil.DBUtil;
public class daop_pe_3 {

	public static boolean insert_pe_3_3_1(String account,String Name,String Sex,String Data,String Education,String Academic,String Graduated_from,String Major,String Title,String Talent_level,String Fixed_Flow,String Nature_of_work,String State,String Company) {
		String sql = "insert into 3t1 values('" + account + "','" + Name  +"','" + Sex  +"','" + Data  +"','" + Education  +"','" + Academic  +"','" + Graduated_from  +"','" + Major  +"','" + Title  +"','" + Talent_level  +"','" + Fixed_Flow  +"','" + Nature_of_work  +"','" + State  +"','" + Company  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
	public static boolean insert_pe_3_3_2(String account,String Name,String Sex,String Data,String Education,String Academic,String Graduated_from,String Major,String Title,String Talent_level) {
		String sql = "insert into 3t2 values('" + account + "','" + Name  +"','" + Sex  +"','" + Data  +"','" + Education  +"','" + Academic  +"','" + Graduated_from  +"','" + Major  +"','" + Title  +"','" + Talent_level  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	public static boolean insert_pe_0t1(String account,String Name,String Sex,String Data,String Education,String Academic,String Graduated_from,String Major,String Title,String Talent_level, String username) {
		String sql = "insert into 0t1 values('" + account + "','" + Name  +"','" + Sex  +"','" + Data  +"','" + Education  +"','" + Academic  +"','" + Graduated_from  +"','" + Major  +"','" + Title  +"','" + Talent_level  +"','" + username  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	public static boolean insert_pe_3_3_3(String account,String Name,String Sex,String Data,String Education,String Academic,String Graduated_from,String Major,String Title,String Talent_level,String Fixed_Flow,String Nature_of_work) {
		String sql = "insert into 3t3 values('" + account + "','" + Name  +"','" + Sex  +"','" + Data  +"','" + Education  +"','" + Academic  +"','" + Graduated_from  +"','" + Major  +"','" + Title  +"','" + Talent_level  +"','" + Fixed_Flow  +"','" + Nature_of_work  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}public static boolean zhengjia(String account,String Name,String Sex,String Data,String Education,String Academic,String Graduated_from,String Major,String Title,String Talent_level,String Fixed_Flow,String Nature_of_work) {
		String sql = "insert into zhengjia values('" + account + "','" + Name  +"','" + Sex  +"','" + Data  +"','" + Education  +"','" + Academic  +"','" + Graduated_from  +"','" + Major  +"','" + Title  +"','" + Talent_level  +"','" + Fixed_Flow  +"','"+ Nature_of_work  +"')";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		boolean f = false;
		int a = 0;
		try {
			state = conn.createStatement();
			a = state.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(state, conn);
		}
		
		if (a > 0) {
			f = true;
		}
		return f;
	}
	
}
